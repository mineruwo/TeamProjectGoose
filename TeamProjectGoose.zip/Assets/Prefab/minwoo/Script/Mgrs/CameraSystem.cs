using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraSystem : MonoBehaviour
{
   public void SetActive()
    {
        gameObject.SetActive(true);
    }
}
